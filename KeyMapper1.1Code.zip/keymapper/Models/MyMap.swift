import SwiftUI

struct MyMap: Identifiable, Codable {
    var id = UUID()
    var fCode: UInt16
    var fFlags: UInt64
    var tCode: UInt16
    var tFlags: UInt64
    var isOn: Bool = true
    
    static func getName(_ c: UInt16, _ f: UInt64) -> String {
        var s = " "
        if (f & 0x40000) != 0 { s += "⌃ " }
        if (f & 0x80000) != 0 { s += "⌥ " }
        if (f & 0x20000) != 0 { s += "⇧ " }
        if (f & 0x100000) != 0 { s += "⌘ " }
        
        let keyMap: [UInt16: String] = [
            0:  "A ", 1:  "S ", 2:  "D ", 3:  "F ", 4:  "H ", 5:  "G ", 6:  "Z ", 7:  "X ", 8:  "C ", 9:  "V ",
            11:  "B ", 12:  "Q ", 13:  "W ", 14:  "E ", 15:  "R ", 16:  "Y ", 17:  "T ", 18:  "1 ", 19:  "2 ",
            20:  "3 ", 21:  "4 ", 22:  "6 ", 23:  "5 ", 24:  "= ", 25:  "9 ", 26:  "7 ", 27:  "-", 28:  "8 ",
            29:  "0 ", 30:  "] ", 31:  "I ", 32:  "U ", 33:  "[ ", 34:  "O ", 35:  "P ", 37:  "L ", 38:  "J ",
            39:  "' ", 40:  "K ", 41:  "; ", 42:  "\\ ", 43:  ", ", 44:  "/ ", 45:  "N ", 46:  "M ", 47:  ". ",
            49:  "Space ", 36:  "↩ ", 51:  "⌫ ", 53:  "Esc ", 48:  "Tab ",
            123:  "← ", 124:  "→ ", 125:  "↓ ", 126:  "↑ "
        ]
        
        return s + (keyMap[c] ?? "K\(c) ")
    }
}